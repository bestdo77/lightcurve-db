# `taos-query`: High-level Abstraction API for TDengine Client

*This package is internally used.*
