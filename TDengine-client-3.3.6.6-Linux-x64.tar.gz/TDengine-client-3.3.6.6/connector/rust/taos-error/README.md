# `taos-error`: Error builder for TDengine Client

*This package is internally used.*
